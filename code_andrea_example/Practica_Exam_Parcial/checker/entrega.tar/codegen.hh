void CodeGen(AST *a,codeglobal &cg);
