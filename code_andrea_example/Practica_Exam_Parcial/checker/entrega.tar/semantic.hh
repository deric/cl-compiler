void TypeCheck(AST *a,string info="");
//void TypeCheck(AST *a);

