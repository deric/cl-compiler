/* ===== semantic.c ===== */
#include <string>
#include <iostream>
#include <map>
#include <list>


using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include "ptype.hh"
#include "symtab.hh"

#define AST_FIELDS string kind;string text;int line;scope *sc;ptype tp;int ref;
#define zzcr_ast(as,attr,tttype,textt) as=new AST;as->kind=(attr)->kind;as->text=(attr)->text;as->line=(attr)->line;as->right=NULL;as->down=NULL;as->sc=0;as->tp=create_type("error",0,0);as->ref=0;
#define createASTlist (*_root)=new AST;((*_root))->kind="list";((*_root))->right=NULL;((*_root))->down=_sibling;
#define GENAST
#include "ast.h"

int TypeError = 0;


void errornumparam(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": The number of parameters in the call do not match."<<endl;
}

void errorincompatibleparam(int l,int n) {
  TypeError = 1;
  cout<<"L. "<<l<<": Parameter "<<n<<" with incompatible types."<<endl;
}

void errorreferenceableparam(int l,int n) {
  TypeError = 1;
  cout<<"L. "<<l<<": Parameter "<<n<<" is expected to be referenceable but it is not."<<endl;
}

void errordeclaredident(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Identifier "<<s<<" already declared."<<endl;
}

void errornondeclaredident(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Identifier "<<s<<" is undeclared."<<endl;
}

void errornonreferenceableleft(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Left expression of assignment is not referenceable."<<endl;
}

void errorincompatibleassignment(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Assignment with incompatible types."<<endl;
}

void errorbooleanrequired(int l,string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Instruction "<<s<<" requires a boolean condition."<<endl;
}

void errorisnotprocedure(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator ( must be applied to a procedure in an instruction."<<endl;
}

void errorisnotfunction(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator ( must be applied to a function in an expression."<<endl;
}

void errorincompatibleoperator(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Operator "<<s<<" with incompatible types."<<endl;
}

void errorincompatiblereturn(int l) {
  TypeError = 1;
  cout<<"L. "<<l<<": Return with incompatible type."<<endl;
}

void errorreadwriterequirebasic(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Basic type required in "<<s<<"."<<endl;
}

void errornonreferenceableexpression(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Referenceable expression required in "<<s<<"."<<endl;
}

void errornonfielddefined(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Field "<<s<<" is not defined in the struct."<<endl;
}

void errorfielddefined(int l, string s) {
  TypeError = 1;
  cout<<"L. "<<l<<": Field "<<s<<" already defined in the struct."<<endl;
}

symtab symboltable;

static void InsertintoST(int line,string kind,string id,ptype tp)
{
  infosym p;

  if (symboltable.find(id) && symboltable.jumped_scopes(id)==0) errordeclaredident(line,id);
  else {
    symboltable.createsymbol(id);
    symboltable[id].kind=kind;
    symboltable[id].tp=tp;
  }
}

bool isbasickind(string kind)
{
  return kind=="int" || kind=="bool";
}

void check_params(AST *a,ptype tp,int line,int numparam);
void insert_vars(AST *a);
void construct_struct(AST *a);
void insert_headers(AST *a);


void TypeCheck(AST *a,string info="")
{
  if (!a) {
    return;
  }

  //cout<<"Starting with node \""<<a->kind<<"\""<<endl;
  if (a->kind=="program") {
    a->sc=symboltable.push();
    insert_vars(a->down->down);
    //insert_headers(a->down->right->down);
    //TypeCheck(a->down->right);
    TypeCheck(a->down->right->right,"instruction");
    symboltable.pop();
  } else if (a->kind=="list") { // At this point only instruction, procedures or parameters list is possible.
    for (AST *a1=a->down;a1!=0;a1=a1->right) {
      TypeCheck(a1,info);
    }
  } else if (a->kind=="ident") {
    if (!symboltable.find(a->text)) {
      errornondeclaredident(a->line, a->text);
    } else {
      a->tp=symboltable[a->text].tp;
      a->ref=1;
    }
  } else if (a->kind=="struct") {
    construct_struct(a);
  } else if (a->kind==":=") {
    TypeCheck(a->down);
    TypeCheck(a->down->right);
    if (!a->down->ref) {
      errornonreferenceableleft(a->line,a->down->text);
    } else if (a->down->tp->kind!="error" && a->down->right->tp->kind!="error" &&
	       !equivalent_types(a->down->tp,a->down->right->tp)) {
      errorincompatibleassignment(a->line);
    } else {
      a->tp=a->down->tp;
    }
  } else if (a->kind=="intconst") {
    a->tp=create_type("int",0,0);
  } else if (a->kind=="+" || (a->kind=="-" && a->down->right!=0) || a->kind=="*"
	     || a->kind=="/") {
    TypeCheck(a->down);
    TypeCheck(a->down->right);
    if ((a->down->tp->kind!="error" && a->down->tp->kind!="int") ||
	(a->down->right->tp->kind!="error" && a->down->right->tp->kind!="int")) {
      errorincompatibleoperator(a->line,a->kind);
    }
    a->tp=create_type("int",0,0);
  } else if (isbasickind(a->kind)) {
    a->tp=create_type(a->kind,0,0);
  } else if (a->kind=="writeln") {
    TypeCheck(a->down);
    if (a->down->tp->kind!="error" && !isbasickind(a->down->tp->kind)) {
      errorreadwriterequirebasic(a->line,a->kind);
    }
  } else if (a->kind==".") {
    TypeCheck(a->down);
    a->ref=a->down->ref;
    if (a->down->tp->kind!="error") {
       if (a->down->tp->kind!="struct") {
            errorincompatibleoperator(a->line,"struct.");
       } else if (a->down->tp->struct_field.find(a->down->right->text)==
	       a->down->tp->struct_field.end()) {
            errornonfielddefined(a->line,a->down->right->text);
       } else {
         a->tp=a->down->tp->struct_field[a->down->right->text];
       }
    }
  } else {
    cout<<"BIG PROBLEM! No case defined for kind "<<a->kind<<endl;
  }

  //cout<<"Ending with node \""<<a->kind<<"\""<<endl;
}

void check_params(AST *a,ptype tp,int line,int numparam)
{
  //...
}

void insert_vars(AST *a)
{
  if (!a) return;
  TypeCheck(a->down);
  InsertintoST(a->line,"idvarlocal",a->text,a->down->tp);
  insert_vars(a->right); 
}

void construct_struct(AST *a)
{
  AST *a1=a->down;
  a->tp=create_type("struct",0,0);

  while (a1!=0) {
    TypeCheck(a1->down);
    if (a->tp->struct_field.find(a1->text)==a->tp->struct_field.end()) {
      a->tp->struct_field[a1->text]=a1->down->tp;
      a->tp->ids.push_back(a1->text);
     } else {
      errorfielddefined(a1->line,a1->text);
    }
    a1=a1->right;
  }
}

void create_header(AST *a)
{
  //...
}


void insert_header(AST *a)
{
  //...
}

void insert_headers(AST *a)
{
  while (a!=0) {
    insert_header(a);
    a=a->right;
  }
}
